from .hais import HAIS
